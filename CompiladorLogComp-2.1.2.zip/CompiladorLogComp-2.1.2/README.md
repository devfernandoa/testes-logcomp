# Status dos Testes

![git status](http://3.129.230.99/svg/devfernandoa/CompiladorLogComp/)

EXPRESSION = TERM, { ("+" | "-"), TERM } ;
TERM = FACTOR, { ("*" | "/"), FACTOR } ;
FACTOR = ("+" | "-") FACTOR | "(" EXPRESSION ")" | number ;

![alt text](image.png)
